# Corrected binding models

- stories260K-binding.bin: step 400, the default binding-demonstration and investigation model.
- stories260K-binding-max.bin: step 600, maximum measured binding with greater ordinary-story drift and rigidity.
- tok512.bin: matching tokenizer.

Step 60 is the held-out story-loss minimum, not the shipped binding model. See binding-profiles.json and binding-evaluation.json for the three educational checkpoint roles.
